package stepdefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import static org.testng.Assert.assertEquals;

public class TranslationStepDefs {

    private String translation;
    private Response response;

    @Given("the country name translation is {string}")
    public void the_country_name_translation_is(String translation) {
        this.translation = translation;
    }

    @When("I send a GET request to the translation endpoint")
    public void i_send_a_get_request_to_the_translation_endpoint() {
        RestAssured.baseURI = "https://restcountries.com/v3.1/translation/";
        response = RestAssured.given().get(this.translation);

    }


//    @When("I send a GET request to the translation endpoint for {string}")
//    public void i_send_a_get_request_to_the_translation_endpoint(String translation) {
//        response = RestAssured.baseURI.trim("https://restcountries.com/v3.1/translation/")
//        .given()
//                .pathParam("translation", translation.trim())
//                .get("/translation/{translation}");
//    }
//

    @Then("the response status code should be 200")
    public void the_response_status_code_should_be_200() {
        assertEquals(response.getStatusCode(), 200);
    }

    @Then("the response should contain valid country data")
    public void the_response_should_contain_valid_country_data() {
        response.then().assertThat().body("name.common", org.hamcrest.Matchers.notNullValue());
    }


}
