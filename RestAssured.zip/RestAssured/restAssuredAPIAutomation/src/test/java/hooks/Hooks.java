package hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
    @Before
    public void setUp() {
        System.out.println("Starting API test...");
    }

    @After
    public void tearDown() {
        System.out.println("Test completed.");
    }
}