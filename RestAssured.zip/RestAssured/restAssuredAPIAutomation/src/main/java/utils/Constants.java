// src/main/java/utils/Constants.java

package utils;

public class Constants {
    // Placeholder URL - currently returns 404
    public static final String BASE_URL = "https://restcountries.com/v3.1/translation/ ";
    public static final String EXCEL_FILE_PATH = "src/test/resources/data/translations.xlsx";
    public static final String SHEET_NAME = "Translations";
}