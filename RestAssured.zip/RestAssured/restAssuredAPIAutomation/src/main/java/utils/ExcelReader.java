package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class ExcelReader {

    public static List<Map<String, String>> getTestData(String filePath, String sheetName) throws IOException {
        List<Map<String, String>> testData = new ArrayList<>();
        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        Row headerRow = sheet.getRow(0);
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row currentRow = sheet.getRow(i);
            Map<String, String> dataMap = new HashMap<>();

            for (int j = 0; j < headerRow.getLastCellNum(); j++) {
                Cell headerCell = headerRow.getCell(j);
                Cell currentCell = currentRow.getCell(j);

                String key = headerCell.toString();
                String value = currentCell != null ? currentCell.toString() : "";
                dataMap.put(key, value);
            }

            testData.add(dataMap);
        }

        workbook.close();
        fis.close();
        return testData;
    }
}