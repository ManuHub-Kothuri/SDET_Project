package hooks;

import base.BaseTest;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class AppHooks {

    @Before
    public void setUp() {
        BaseTest.getDriver();


    }

    @After
    public void tearDown() {
        BaseTest.quitDriver();
    }

//    @After
//    public void quitBrowser() {
//        BaseTest base = new BaseTest();
//        base.tearDown();
//    }
}