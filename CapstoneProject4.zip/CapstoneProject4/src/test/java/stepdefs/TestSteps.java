package stepdefs;

import base.BaseTest;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Pages.*;

public class TestSteps extends BaseTest {

    private HomePage homePage;
    private AbTestPage abTestPage;
    private DropdownPage dropdownPage;
    private FramesPage framesPage;



    @Given("I launch the application")
    public void launchApplication() {
        BaseTest.getDriver().get("http://the-internet.herokuapp.com/");
        homePage = new HomePage(driver);
    }



    @Then("I verify the title of the page is {string}")
    public void verifyTitle(String expectedTitle) {
        super.verifyTitle(expectedTitle);
    }

    @When("I click on AB Testing link")
    public void clickABTestingLink() {
        homePage.clickABTestingLink();
        abTestPage = new AbTestPage(driver);
    }

    @Then("I verify the text {string} is displayed")
    public void verifyABText(String expectedText) {
        String actualText = abTestPage.getHeaderText();
        super.verifyText(actualText, expectedText);
    }

    @When("I navigate back to home page")
    public void navigateBackToHome() {
        driver.navigate().back();
    }

    @And("click on dropdown link")
    public void clickDropdownLink() {
        homePage.clickDropdownLink();
        dropdownPage = new DropdownPage(driver);
    }

    @And("select Option1 from dropdown")
    public void selectOption1FromDropdown() {
        dropdownPage.selectOption1();
    }

    @And("verify Option1 is selected")
    public void verifyOption1Selected() {
        String selected = dropdownPage.getSelectedOption();
        Assert.assertEquals(selected, "Option 1");
    }

    @And("click on Frames link")
    public void clickFramesLink() {
        homePage.clickFramesLink();
        framesPage = new FramesPage(driver);
    }

    @Then("I verify Nested Frames and iFrame links are present")
    public void verifyNestedFramesAndIFramePresent() {
        Assert.assertTrue(framesPage.isNestedFramesDisplayed());
        Assert.assertTrue(framesPage.isIFrameDisplayed());
    }


}