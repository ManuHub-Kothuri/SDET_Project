package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AbTestPage {
    private WebDriver driver;

    public AbTestPage(WebDriver driver) {
        this.driver = driver;
    }

    private By headerText = By.tagName("h3");

    public String getHeaderText() {
        return driver.findElement(headerText).getText();
    }
}