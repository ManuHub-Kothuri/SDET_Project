package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    private By abTestingLink = By.linkText("A/B Testing");
    private By dropdownLink = By.linkText("Dropdown");
    private By framesLink = By.linkText("Frames");

    public void clickABTestingLink() {
        driver.findElement(abTestingLink).click();
    }

    public void clickDropdownLink() {
        driver.findElement(dropdownLink).click();
    }

    public void clickFramesLink() {
        driver.findElement(framesLink).click();
    }
}