package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class DropdownPage {
    private WebDriver driver;

    public DropdownPage(WebDriver driver) {
        this.driver = driver;
    }

    private By dropdown = By.id("dropdown");

    public void selectOption1() {
        Select select = new Select(driver.findElement(dropdown));
        select.selectByVisibleText("Option 1");
    }

    public String getSelectedOption() {
        Select select = new Select(driver.findElement(dropdown));
        WebElement selectedOption = select.getFirstSelectedOption();
        return selectedOption.getText();
    }
}