package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FramesPage {
    private WebDriver driver;

    public FramesPage(WebDriver driver) {
        this.driver = driver;
    }

    private By nestedFramesLink = By.linkText("Nested Frames");
    private By iframeLink = By.linkText("iFrame");

    public boolean isNestedFramesDisplayed() {
        return driver.findElement(nestedFramesLink).isDisplayed();
    }

    public boolean isIFrameDisplayed() {
        return driver.findElement(iframeLink).isDisplayed();
    }
}