def verify_checkbox_state(checkbox_element, expected_state):
    assert checkbox_element.is_selected() == expected_state