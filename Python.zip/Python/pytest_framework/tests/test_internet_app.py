from selenium.webdriver.common.by import By
from utilities.helper import verify_checkbox_state



def test_homepage_title(browser, base_url):
    browser.get(base_url)
    assert "The Internet" in browser.title

def test_checkboxes_operations(browser, base_url):
    browser.get(base_url)
    browser.find_element(By.LINK_TEXT, "Checkboxes").click()
    assert browser.find_element(By.TAG_NAME, "h3").text == "Checkboxes"
    
    checkboxes = browser.find_elements(By.CSS_SELECTOR, "input[type='checkbox']")
    verify_checkbox_state(checkboxes[0], False)
    verify_checkbox_state(checkboxes[1], True)
    
    browser.back()

def test_file_upload(browser, base_url, tmp_path):
    browser.get(base_url)
    browser.find_element(By.LINK_TEXT, "File Upload").click()
    assert browser.find_element(By.TAG_NAME, "h3").text == "File Uploader"
    
    file = tmp_path / "test_file.txt"
    file.write_text("test content")
    
    browser.find_element(By.ID, "file-upload").send_keys(str(file))
    browser.find_element(By.ID, "file-submit").click()
    
    assert "File Uploaded!" in browser.find_element(By.TAG_NAME, "h3").text